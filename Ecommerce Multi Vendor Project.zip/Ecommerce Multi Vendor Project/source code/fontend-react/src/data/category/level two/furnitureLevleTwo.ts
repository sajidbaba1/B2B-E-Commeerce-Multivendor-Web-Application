export const furnitureLevelTwo=[
    {
      "name": "Bed Linen & Furnishing",
      "categoryId": "bed_linen_furnishing",
      "parentCategoryName": "Furniture",
      "parentCategoryId": "furniture",
      "level": 2
    },
    {
      "name": "Flooring",
      "categoryId": "flooring",
      "parentCategoryName": "Furniture",
      "parentCategoryId": "furniture",
      "level": 2
    },
    {
      "name": "Bath",
      "categoryId": "bath",
      "parentCategoryName": "Furniture",
      "parentCategoryId": "furniture",
      "level": 2
    },
    {
      "name": "Lamps & Lighting",
      "categoryId": "lamps_lighting",
      "parentCategoryName": "Furniture",
      "parentCategoryId": "furniture",
      "level": 2
    },
    {
      "name": "Home Décor",
      "categoryId": "home_decor",
      "parentCategoryName": "Furniture",
      "parentCategoryId": "furniture",
      "level": 2
    },
    {
      "name": "Kitchen & Table",
      "categoryId": "kitchen_table",
      "parentCategoryName": "Furniture",
      "parentCategoryId": "furniture",
      "level": 2
    },
    // {
    //   "name": "Storage",
    //   "categoryId": "storage",
    //   "parentCategoryName": "Furniture",
    //   "parentCategoryId": "furniture",
    //   "level": 2
    // },
  
  ]
  
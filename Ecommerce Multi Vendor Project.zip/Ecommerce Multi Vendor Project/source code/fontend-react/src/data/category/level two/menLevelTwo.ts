export const menLevelTwo=[
    {
        "name": "Topwere",
        "categoryId": "men_topwear",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Bottomwere",
        "categoryId": "men_bottomwear",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Innerwere And Sleepwere",
        "categoryId": "men_innerwear_and_sleepwear",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Footwere",
        "categoryId": "men_footwear",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Persional Care And  grooming",
        "categoryId": "men_personal_care_and_grooming",
        "parentCategoryId":"men",
        "level":2
    },
    {
        "name": "Fashion Accessories",
        "categoryId": "men_fashion_accessories",
        "parentCategoryId":"men",
        "level":2
    },
    // {
    //     "name": "Gadgets",
    //     "categoryId": "men_gadgets",
    //     "parentCategoryId":"men",
    //     "level":2
    // },
    // {
    //     "name": "Bags And Backpacks",
    //     "categoryId": "men_bags_and_backpacks",
    //     "parentCategoryId":"men",
    //     "level":2
    // }
]
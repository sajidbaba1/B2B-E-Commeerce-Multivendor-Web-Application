export const brands=[
    {"name": "nike", "value": "nike"},
    {"name": "FabIndia", "value": "fabindia"},
    {"name": "Biba", "value": "biba"},
    {"name": "Manyavar", "value": "manyavar"},
    {"name": "W for Woman", "value": "wforwoman"},
    {"name": "Allen Solly", "value": "allen_solly"},
    {"name": "Peter England", "value": "peter_england"},
    {"name": "Pantaloons", "value": "pantaloons"}
  ]
  
export const topBrandData=[
    {name:"Rubans",
        image:"https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/15189594/2022/2/1/efde4d54-98ca-40cc-89f1-b5787bc532b11643659231979Rubans24KGold-PlatedRuby-StuddedBeadedHandcraftedJewellerySe5.jpg"},
        {
            name:"Fabcartz",
            image:"https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/23807268/2023/6/29/9930b235-5318-4755-abbe-08f99e969e781688026636544LehengaCholi7.jpg",

        },
        {name:"manyawar",
            image:"https://shreeman.in/cdn/shop/files/20_3cfbd5a3-ecb6-482a-b798-7ffd9de1c784.jpg?v=1712061674&width=700"
        },
        {
            name:"LOUIS STITCH",
            image:"https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/24651572/2023/8/25/4fbf6d8c-d093-46c5-a5a6-7dd67c0c76551692964752597HouseofPataudiMenTanFauxLeatherFormalSlipOnLoafers1.jpg"
        },
        {
            name:"Anouk",
            image:"https://assets.myntassets.com/h_720,q_90,w_540/v1/assets/images/13837166/2021/8/19/04e40e02-4c56-4705-94d0-f444b29973aa1629373611707-House-of-Pataudi-Women-Maroon-Embellished-Handcrafted-Wedges-1.jpg"
        }
]
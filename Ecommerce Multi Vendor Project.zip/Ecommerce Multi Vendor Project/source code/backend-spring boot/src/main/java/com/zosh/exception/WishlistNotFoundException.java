package com.zosh.exception;

public class WishlistNotFoundException extends Exception{
    public WishlistNotFoundException(String message){
        super(message);
    }
}

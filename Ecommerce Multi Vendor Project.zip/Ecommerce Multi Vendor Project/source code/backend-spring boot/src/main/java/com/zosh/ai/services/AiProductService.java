package com.zosh.ai.services;

public interface AiProductService {

    String simpleChat(String prompt);

}
